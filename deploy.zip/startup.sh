node server.js
